.: LARAVEL, JETSREAM, INERTIA, VUE, TAILWIND :.
===============================================


1. Membuat Register & Login dengan Jetrstream
- composer create-project laravel/laravel sim
- composer require laravel/jetstream
- php artisan jetstream:install inertia
- npm install
- npm run dev
- buat database di phpmyadmin dengan nama dbsim
- sesuaikan nama database di file .env
- update file user migration dengan menambahkan dua field baru yaitu username dan phone
- update file User Model dan tambahkan username dan phone di dalam protected $fillable
- php artisan migrate
- update file Register.vue di halaman register atau di file resources/js/Pages/Auth
- update file Login.vue di halaman login atau di file resources/js/Pages/Auth
- update file CreateNewUsere.php di app/Actions/Fortify/
- update file fortify.php di config/ cari dan ubah 'username' => 'email', menjadi 'username' => 'auth',
- update file jetstream.php di config/ cari dan hilangkan tanda '//' pada "Features::profilePhotos(),"
- update file JetstreamServiceProvider.php di app/Providers/
- php artisan storage:link
- update file .env edit : APP_URL=http://localhost:8000


2. Membuat Sidebar dan Navbar untuk Administrator
- buat file home.vue di folder resources/js/Pages/Admins
- php artisan make:controller Admins/HomeController -r
- update file HomeController.php di folder Admins/HomeController pada bagian public function index()
- buat folder Partials di resources/js/Layouts/
- buat file navbar.vue di folder resources/js/Layouts/Partials
- buat file sidebar.vue di folder resources/js/Layouts/Partials
- buat file AccountDropDown.vue di folder resources/js/Layouts/Partials
- buat file AdminLayout.vue di folder resources/js/Layouts
- update file AppLayout.vue di folder resources/js/Layouts
- update file web.php di folder routes


3. Membuat CRUD : Tampilkan data golpangs di table
- php artisan make:model Golpang -m
- update file Golpang migration
- update file Golpang Model
- php artisan migrate
- update file Kernel.php di folder app/Http
- php artisan make:controller Admins/GolpangController -r
- update file GolpangController.php di folder Admins/GolpangController pada bagian public function index()
- update file app.blade.php di folder resources/views
- buat folder Golpangs di resources/js/Pages/Admins
- buat file index.vue di folder resources/js/Pages/Admins/Golpangs
- buat file create.vue di folder resources/js/Pages/Admins/Golpangs
- buat file edit.vue di folder resources/js/Pages/Admins/Golpangs
- buat file sidebar.vue di folder resources/js/Layouts/Partials
- update file web.php di folder routes


4. Membuat CRUD : Tambah, edit, hapus data golpangs
- update file create.vue di folder resources/js/Pages/Admins/Golpangs
- update file edit.vue di folder resources/js/Pages/Admins/Golpangs
- update file GolpangController.php di folder Admins/GolpangController


5. Membuat CRUD : Repair script hapus data
- update file GolpangController.php di folder Admins/GolpangController
- update file index.vue di folder resources/js/Pages/Admins/Golpangs
- update file web.php di folder routes


6. Membuat Pencarian dan Paginasi
- update file Golpang di folder app/Models
- update file GolpangController.php di folder Admins/GolpangController
- update file index.vue di folder resources/js/Pages/Admins/Golpangs
- buat folder Components di resources/js
- buat file Pagination.vue di folder resources/js


7. Repair script
- update file index.vue di folder resources/js/Pages/Admins/Golpangs
- update file create.vue di folder resources/js/Pages/Admins/Golpangs
- update file edit.vue di folder resources/js/Pages/Admins/Golpangs


8. Membuat breadcrumb
- update file index.vue di folder resources/js/Pages/Admins/Golpangs
- update file create.vue di folder resources/js/Pages/Admins/Golpangs
- update file edit.vue di folder resources/js/Pages/Admins/Golpangs
- update file AdminLayout.vue di folder resources/js/Layouts


9. Membuat Role & permission dengan Spatie Part 1
- composer require spatie/laravel-permission
- php artisan vendor:publish --provider="Spatie\Permission\PermissionServiceProvider"
- setelah publish sebaiknya optimasi dan clear cache dengan cara : php artisan optimize:clear atau php artisan config:clear
- php artisan migrate
- update file Kernel.php di folder app/Http dan tambahkan : 
    'role' => \Spatie\Permission\Middlewares\RoleMiddleware::class,
    'permission' => \Spatie\Permission\Middlewares\PermissionMiddleware::class,
    'role_or_permission' => \Spatie\Permission\Middlewares\RoleOrPermissionMiddleware::class,
- edit file HandleInertiaRequests.php in folder app/Http/Middleware
- php artisan make:seeder RoleSeeder
- edit file RoleSeeder.php di folder /database/seeders
- php artisan make:seeder PermissionSeeder
- edit file PermissionSeeder.php di folder /database/seeders
- php artisan make:seeder UserSeeder
- edit file UserSeeder.php di folder /database/seeders
- php artisan make:seeder RoleAndPermissionSeeder
- edit file RoleAndPermissionSeeder.php di folder /database/seeders
- php artisan make:seeder GolpangSeeder
- edit file GolpangSeeder.php di folder /database/seeders
- edit file _create_permission_tables.php di folder/database/migrations dan tambahkan : 
    Artisan::call('db:seed', [ 
        '--class' => RoleSeeder::class, 
    ]);
    Artisan::call('db:seed', [
        '--class' => PermissionSeeder::class,
    ]);
    Artisan::call('db:seed', [
        '--class' => UserSeeder::class,
    ]);
    Artisan::call('db:seed', [
        '--class' => RoleAndPermissionSeeder::class,
    ]);
- update file User di folder app/Models
- update file Golpang di folder app/Models
- update file sidebar.vue di folder resources/js/Layouts/Partials
- update file web.php di folder routes
- php artisan migrate:refresh


10. Membuat Role & permission dengan Spatie Part 2 (Repair dan tambah script)
- php artisan make:controller Admins/PermissionsController -r
- update file PermissionsController.php di folder app/Http/Controllers/Admins pada bagian public function index()
- php artisan make:controller Admins/RolesController -r
- update file RolesController.php di folder app/Http/Controllers/Admins pada bagian public function index()
- buat folder Permissions di resources/js/Pages/Admins
- buat file index.vue di folder resources/js/Pages/Admins/Permissions
- buat file create.vue di folder resources/js/Pages/Admins/Permissions
- buat file edit.vue di folder resources/js/Pages/Admins/Permissions
- buat folder Roles di resources/js/Pages/Admins
- buat file index.vue di folder resources/js/Pages/Admins/Roles
- buat file create.vue di folder resources/js/Pages/Admins/Roles
- buat file edit.vue di folder resources/js/Pages/Admins/Roles
- buat folder Users di app/Http/Controllers
- buat folder Users di resources/js/Pages
- buat folder Biodatas di resources/js/Pages/Users
- php artisan make:controller Users/BiodataController -r
- buat file index.vue di folder resources/js/Pages/Users/Permissions
- buat file create.vue di folder resources/js/Pages/Users/Permissions
- buat file edit.vue di folder resources/js/Pages/Users/Permissions
- update file BiodataController.php di folder app/Http/Controllers/Users pada bagian public function index()
- buat file sidebar.vue di folder resources/js/Layouts/Partials
- update file web.php di folder routes


11. Membuat Role & permission dengan Spatie Part 3 (Repair dan tambah script)
- Ganti nama folder Users menjadi Member
- buat file index.vue di folder resources/js/Pages/Members/Biodatas
- buat file create.vue di folder resources/js/Pages/Members/Biodatas
- buat file edit.vue di folder resources/js/Pages/Members/Biodatas
- update file AppLayout.vue pada folder /resources/js/Layouts/
- update file AccountDropDown.vue pada folder /resources/js/Layouts/Partials/
- update file sidebar.vue di folder resources/js/Layouts/Partials
- update file web.php di folder routes
- update file RoleSeeder.php di folder /database/seeders
- update file PermissionSeeder.php di folder /database/seeders
- update file UserSeeder.php di folder /database/seeders
- update file RoleAndPermissionSeeder.php di folder /database/seeders
- php artisan migrate:refresh


12. Membuat Role & permission dengan Spatie Part 4 (Repair dan tambah script)
- php artisan make:model Role -m
- update file Role Model
- php artisan make:model Permission -m
- update file Role Permission
- update file RolesController.php di folder app/Http/Controllers/Admins
- update file PermissionsController.php di folder app/Http/Controllers/Admins
- update file index.vue di folder resources/js/Pages/Admins/Roles
- update file create.vue di folder resources/js/Pages/Admins/Roles
- update file edit.vue di folder resources/js/Pages/Admins/Roles
- update file index.vue di folder resources/js/Pages/Admins/Permissions
- update file create.vue di folder resources/js/Pages/Admins/Permissions
- update file edit.vue di folder resources/js/Pages/Admins/Permissions
- update file sidebar.vue di folder resources/js/Layouts/Partials
- update file web.php di folder routes


13. Membuat Role & permission dengan Spatie Part 5 (Repair dan tambah script)
- php artisan make:model Ropes -m
- update file Ropes Model
- update file RolesController.php di folder app/Http/Controllers/Admins
- update file AppServiceProvider.php pda app/Providers/
- update file index.vue di folder resources/js/Pages/Admins/Roles- 
- buat file PublicLayout.vue di folder resources/js/Layouts
- rename Dashboard.vue menjadi Dashboard2.vue pada resources/js/Pages
- buat file Dashboard.vue pada resources/js/Pages
- update file web.php di folder routes
- update file sidebar.vue di folder resources/js/Layouts/Partials
- update file web.php di folder routes


14. Membuat Halaman Publik
- php artisan make:controller PublicController -r
- update file PublicController.php di folder app/Http/Controllers
- update file AppLayout.vue di folder resources/js/Layouts
- buat file PublicLayout.vue di folder resources/js/Layouts
- buat folder Publics
- buat folder Profil, InformasiPublik, InformasiDikecualikan, LayananPublik didalam folder Publics
- buat file index.vue di masing-masing folder yang telah dibuat sebelumnya
- buat file DIP.vue di folder Publics
- update file web.php di folder routes


15. Membuat Halaman Public part 2
- update file PublicController.php di folder app/Http/Controllers
- update file app.php di folder config
- update file PublicLayout.vue di folder resources/js/Layouts
- update file sidebar.vue di folder resources/js/Layouts/Partials
- update file Dashboard.vue pada resources/js/Pages
- update file app.blade.php di folder routes
- update file web.php di folder resources/views
- php artisan make:model InformasiDikecualikan -m
- update file table informasidikecualikans pada folder migrations
- update file Golpang pada folder Models
- php artisan migrate
- php artisan make:controller Admins/InformasiDikecualikanController -r
- update file InformasiDikecualikanController.php di folder app/Http/Controllers/Admins
- buat folder InformasiDikecualikans di resources/js/Pages/Admins
- buat file index.vue di folder resources/js/Pages/Admins/InformasiDikecualikans
- php artisan make:model Berita -m
- update file table beritass pada folder migrations
- update file Berita pada folder Models
- php artisan migrate
- php artisan make:controller Admins/BeritaController -r
- update file BeritaController.php di folder app/Http/Controllers/Admins
- buat folder Beritas di resources/js/Pages/Admins
- buat file index.vue di folder resources/js/Pages/Admins/Beritas
- buat file create.vue di folder resources/js/Pages/Admins/Beritas
- buat file edit.vue di folder resources/js/Pages/Admins/Beritas
- buat file index.vue di folder resources/js/Pages/Publics/Berita
- buat file detail.vue di folder resources/js/Pages/Publics/Berita


16. Membuat Halaman Public part 3
- composer require cviebrock/eloquent-sluggable
- composer require te7a-houdini/laravel-trix
- php artisan vendor:publish --provider="Te7aHoudini\LaravelTrix\LaravelTrixServiceProvider"
- update file app.js di folder resources/js
- update file app.blade.view di folder resources/views
- update file Berita pada folder Models
- update file create.vue pada folder resources/js/Pages/Admins/Beritas
- update file edit.vue pada folder resources/js/Pages/Admins/Beritas
- update file index.vue pada folder resources/js/Pages/Publics/Beritas
- update file detail.vue pada folder resources/js/Pages/Publics/Beritas
- update file index.vue pada folder resources/js/Pages/Publics/Profil
- update file DIP.vue pada folder resources/js/Pages/Publics/
- update file index.vue pada folder resources/js/Pages/Publics/InformasiPublik
- update file index.vue pada folder resources/js/Pages/Publics/LayananPublik
- update file PublicLayout.vue pada folder resources/js/Layouts
- update file Dashboard.vue pada folder resources/js
- update file PublicController.php di folder app/Http/Controllers
- buat folder images di dalam folder public, masukkan file logo dan banner
- update file web.php di folder routes


17. Perbaikan Code & redirect sesudah login-logout
- update file Berita pada folder Models
- update file Roper pada folder Models
- update file InformasiDikecualikanController.php di folder app/Http/Controllers/Admins
- update file BeritaController.php di folder app/Http/Controllers/Admins
- update file RolesController.php di folder app/Http/Controllers/Admins
- update file AppLayout.vue di folder resources/js/Layouts
- update file PublicLayout.vue di folder resources/js/Layouts
- update file sidebar.vue di folder resources/js/Layouts/Partials
- update file Dashboard.vue pada resources/js/Pages
- update file create.vue pada folder resources/js/Pages/Admins/Beritas
- update file edit.vue pada folder resources/js/Pages/Admins/Beritas
- update file index.vue pada folder resources/js/Pages/Publics/Beritas
- update file index.vue pada folder resources/js/Pages/Publics/Roles
- update file roper.vue pada folder resources/js/Pages/Publics/Roles
- update file detail.vue di folder resources/js/Pages/Publics/Berita
- Buat Folder Responses pada folder app/Http
- Buat file LoginResponse.php di folder app/Http/Responses
- Buat file LogoutResponse.php di folder app/Http/Responses
- update file FortifyServiceProvider.php di folder app/Providers
- update file web.php di folder routes


18. Penghapusan code dan perbaikan
- Hapus Golpang pada Controller, Modul, table, Seeder
- update file PublicLayout.vue di folder resources/js/Layouts
- update file sidebar.vue di folder resources/js/Layouts/Partials
- update file index.vue pada folder resources/js/Pages/Admins/Beritas
- update file index.vue pada folder resources/js/Pages/Admins/Informasi-Dikecualikans
- update file app.blade pada folder resources/views
- update file web.php di folder routes
- update file PermissionSeeder.php pada folder database/seeders
- update file RoleSeeder.php pada folder database/seeders
- update file RoleAndPermissionSeeder.php pada folder database/seeders
- update file UserSeeder.php pada folder database/seeders
- update file web.php di folder routes


19. Disable menu register dan lupa password
- update file fortify.php pada folder config : 
    //Features::registration(),
    //Features::resetPasswords(),